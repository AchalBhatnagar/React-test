import Axios from "axios";
import store from "../redux/store";

export default class HomeService {
    callWeatherApi(params) {
        return Axios.get("https://cat-fact.herokuapp.com/facts")
    };
}