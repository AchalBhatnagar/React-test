import { Component } from "react";
import store from "../../redux/store";
import HomeView from "./HomeView";
import HomeService from "../../services/homeService"

export default class HomeContainer extends Component {
    constructor() {
        super()
        this.state = {
            data: 'test'
        }
    }
    render() {
        return (<div>
            <HomeView state={this.state.data} addUser={this.addUser.bind(this)} getData={this.getData.bind(this)} />
        </div>);
    }

    addUser(name) {
        // store.subscribe(() => {
        //     this.setState({ data: store.getState() });
        // });

        // store.dispatch({ type: 'ADD_USER', payload: name });
    }

    getData() {
        var a = new HomeService();
        a.callWeatherApi().then((response) => {
            console.log(response);
            store.dispatch({ type: 'JSON_INITIAL', payload: response });
            this.setState({ data: store.getState() });
        });;
    }
}