import { makeStyles, Paper, Table, TableCell, TableContainer, TableHead, TableRow, TableBody } from "@material-ui/core";
import { Component } from "react";

const useStyles = makeStyles({
    table: {
        minWidth: 650,
    },
});

function HomeView(parentState) {
    const showTable = () => {
        if (parentState.data.payload) {
            return <div>{BasicTable(parentState.data?.payload?.data?.all)}</div>
        }
    }
    return (
        <div className="demo" >
            <button onClick={() => {
                parentState.getData()
            }
            }> Click</button >
            { showTable()}
        </div >
    );

}

function BasicTable(rows) {
    const classes = useStyles();
    return (<TableContainer component={Paper}>
        <Table className={classes.table} aria-label="simple table">
            <TableHead>
                <TableRow>
                    <TableCell align="right">Text</TableCell>
                    <TableCell align="right">Type&nbsp;(g)</TableCell>
                    {/* <TableCell align="right">Carbs&nbsp;(g)</TableCell> */}
                    {/* <TableCell align="right">Protein&nbsp;(g)</TableCell> */}
                </TableRow>
            </TableHead>
            <TableBody>
                {rows.map((row) => (
                    <TableRow key={row._id}>
                        <TableCell component="th" scope="row">
                            {row.text}
                        </TableCell>
                        <TableCell align="right">{row.type}</TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    </TableContainer>);

}

export default HomeView;