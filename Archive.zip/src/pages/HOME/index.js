const { default: HomeContainer } = require("./HomeContainer");

function Home() {
    return (<HomeContainer />)
}

export default Home;