import react from "react"
function Page1() {
    return (
        <Page1 className="demo">
            <div>front</div>
            <div>back</div>
        </Page1>
    );
}

export default Page1;