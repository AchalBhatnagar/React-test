function addUserName(name) {
    return {
        type: 'ADD_USER',
        name
    }
}

function getApiData() {
    return {
        type: 'JSON_INITIAL',
        name
    }
}