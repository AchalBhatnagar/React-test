import { Route, Switch } from "react-router-dom";
import Home from "../pages/HOME";


export const RouterConfig = () => {
    return (
        <Switch>
            <Route path="/home" component={Home}>
            </Route>
            {/* <PrivateRoute path={PAGE1}>
                <Page1 />
            </PrivateRoute> */}
            {/* <Route path='*'>
                <NotFound />
            </Route> */}
        </Switch>
    );

}

export default RouterConfig;    