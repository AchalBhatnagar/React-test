import './App.css';
import NavHeaderContent from './components/side-nav/NavHeaderContent.js'
import { BrowserRouter as Router } from "react-router-dom";
import RouterConfig from './navigation/RouterConfig';


function App() {
  return (
    <Router>
      <NavHeaderContent>
        <RouterConfig />
      </NavHeaderContent>
    </Router>
  );
}

export default App;
