import { Route, Switch } from "react-router-dom";
import Home from "../pages/HOME";
import Page1 from "../pages/PAGE1/Page1View";
import NotFound from "./NotFound";


export const RouterConfig = () => {
    return (
        <Switch>
            <Route path="/home" component={Home}>
            </Route>
            <Route exact path="/" component={Page1}>
            </Route>
            <Route path='*' component={NotFound}>
            </Route>
        </Switch>
    );

}

export default RouterConfig;    