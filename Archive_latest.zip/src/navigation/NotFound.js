import react from "react"

export default function NotFound() {
    return (<>HI</>)
}