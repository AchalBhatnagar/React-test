export const LITERALS = {
    header: 'Compliance Reporting Service'
}