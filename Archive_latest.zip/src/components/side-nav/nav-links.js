import IconDashboard from "@material-ui/icons/Dashboard";
import IconShoppingCart from "@material-ui/icons/ShoppingCart";
import IconPeople from "@material-ui/icons/People";
import IconBarChart from "@material-ui/icons/BarChart";
import IconLibraryBooks from "@material-ui/icons/LibraryBooks";

export const menuLinks = [{
    path: '/home',
    label: 'Home',
    icon: IconPeople,
    children: [{
        path: '/',
        label: 'child1',
        icon: IconBarChart,
    }, {
        path: '/',
        label: 'child2',
        icon: IconBarChart,
    }
    ]

}, {
    path: '/',
    label: 'Mail',
    icon: IconDashboard

}];