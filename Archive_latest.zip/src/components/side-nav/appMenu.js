import React from 'react';
import { Link } from 'react-router-dom';
import Collapse from '@material-ui/core/Collapse'
import IconExpandLess from '@material-ui/icons/ExpandLess'
import IconExpandMore from '@material-ui/icons/ExpandMore'
import { createStyles, Divider, List, ListItemIcon, ListItem, ListItemText, makeStyles } from '@material-ui/core';

const useStyles = makeStyles(() =>
    createStyles({
        menuItem: {},
        menuItemIcon: {
            color: '#03142a',
        },
    }),
)

export function AppMenu(props) {
    const { link } = props;

    const classes = useStyles()
    const isExpandable = link.children && link.children.length > 0
    const [open, setOpen] = React.useState(false)

    function handleClick() {
        setOpen(!open)
    }

    const MenuItemRoot = (
        <ListItem button className={classes.menuItem} onClick={handleClick} component={Link} to={link.path}>
            {/* Display an icon if any */}
            {!!link.icon && (
                <ListItemIcon className={classes.menuItemIcon}>
                    <link.icon />
                </ListItemIcon>
            )}
            <ListItemText primary={link.label} inset={!link.icon} />
            {/* Display the expand menu if the item has children */}
            {isExpandable && !open && <IconExpandMore />}
            {isExpandable && open && <IconExpandLess />}
        </ListItem>
    )

    const MenuItemChildren = isExpandable ? (
        <Collapse in={open} timeout="auto" unmountOnExit>
            <Divider />
            <List component="div" disablePadding>
                {link.children.map((item, index) => (
                    <AppMenu link={item} key={index} />
                ))}
            </List>
        </Collapse>
    ) : null

    return (<>
        {MenuItemRoot}
        {MenuItemChildren}
    </>)
}