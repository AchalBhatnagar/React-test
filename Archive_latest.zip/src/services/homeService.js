import Axios from "axios";

export default class HomeService {
    callWeatherApi() {
        return Axios.get("https://cat-fact.herokuapp.com/facts")
    };
}