import react from "react"
function Page1() {
    return (
        <div className="demo">
            <div>front</div>
            <div>back</div>
        </div>
    );
}

export default Page1;