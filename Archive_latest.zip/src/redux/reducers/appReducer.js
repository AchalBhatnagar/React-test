var initialState = {};

export default function appReducer(state = initialState, action) {
    switch (action.type) {
        case 'ADD_USER':
            return {
                ...state,
                users: [
                    ...state.users, {
                        name: action.payload,
                        id: 2
                    }
                ]

            }
        case 'JSON_INITIAL':
            return {
                ...state,
                ...action
            }
    }
    return state;
}
