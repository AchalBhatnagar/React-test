export const ACTIONS = [
    { type: 'ADD_USER', payload: userName }
];